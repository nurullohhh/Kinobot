import telebot
import json
import os
from config import TOKEN
from keep_alive import keep_alive

bot = telebot.TeleBot(TOKEN)
keep_alive()

ADMIN_COMMANDS = ['/add_kino', '/remove_kino', '/list_kinos', '/add_admin', '/remove_admin', '/admins', '/stats']

def load_json(path):
    with open(path, 'r') as f:
        return json.load(f)

def save_json(path, data):
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)

DATA_PATH = "data"
kino_file = os.path.join(DATA_PATH, "kino_data.json")
admin_file = os.path.join(DATA_PATH, "admins.json")

@bot.message_handler(commands=['start'])
def start(message):
    bot.reply_to(message, "🎬 Salom! Kino kodi yoki link yuboring.")

@bot.message_handler(func=lambda message: True)
def handle_message(message):
    if str(message.chat.id) in load_json(admin_file):
        if message.text == '/list_kinos':
            kinos = load_json(kino_file)
            if not kinos:
                bot.reply_to(message, "📭 Hech qanday kino yo'q.")
            else:
                text = '\n'.join([f"{k}: {v['title']}" for k, v in kinos.items()])
                bot.reply_to(message, text)
        # Add more admin commands here
    else:
        # Kino kodi asosida yuborish
        kinos = load_json(kino_file)
        kino = kinos.get(message.text)
        if kino:
            bot.send_message(message.chat.id, f"🎬 {kino['title']}")
            bot.send_video(message.chat.id, kino['file_id'])
        else:
            bot.reply_to(message, "❌ Bunday kino topilmadi.")

bot.polling()
